package com.experion.service;

import java.sql.Date;

public interface LoanService {
	public abstract void checkDueDate();
	public abstract void loanApproval();
	
}
